#include <bits/stdc++.h>

using namespace std;

int x, y;

int main(){
    scanf("%d %d", &x, &y);
    printf("%d\n", (x-1)^(y-1));
}
